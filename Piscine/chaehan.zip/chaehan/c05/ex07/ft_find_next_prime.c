#include <stdio.h>

int	ft_sqrt(int nb)
{
	long long i;

	i = 1;
	while (i * i <= nb)
		i++;
	return (i - 1);
}

int is_prime(int nb)
{
	int i;

	i = 2;
	if (nb <= 1)
		return (0);
	if (nb == 2)
		return (1);
	while (i <= ft_sqrt(nb))
	{
		if (nb % i == 0)
			return (0);
		i++;
	}
	return (1);
}

int	ft_find_next_prime(int nb)
{
	int temp;

	temp = nb;
	while (temp)
	{
		if (is_prime(temp) == 1)
			return (temp);
		temp++;
	}
	return (0);
}

int	main(void)
{
	for (int i = -10; i<10; i++)
		printf("%d %d\n",i,ft_find_next_prime(i));
}
