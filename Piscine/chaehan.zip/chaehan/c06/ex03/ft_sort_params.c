#include <stdio.h>
#include <unistd.h>

int	ft_strcmp(char *st1, char *st2)
{
	while (*st1 != '\0' && *st2 != '\0')
	{
		if (*st1 == *st2)
		{
			st1++;
			st2++;
		}
		else if (*st1 > *st2)
			return (1);
		else if (*st1 < *st2)
			return (-1);
	}
	return (0);
}

int	main(int argc, char *argv[])
{
	int		i;
	char	*temp;

	i = 1;
	while (i < argc - 1)
	{
		if (ft_strcmp(argv[i],argv[i + 1]) == 1)
		{
			temp = argv[i];
			argv[i] = argv[i + 1];
			argv[i + 1] = temp;
			i = 1;
		}
		i++;
	}
	i = 1;
	while (i < argc)
	{
		while (*argv[i])
			write(1, argv[i]++, 1);
		i++;
		write(1, "\n", 1);
	}
	return (0);
}
