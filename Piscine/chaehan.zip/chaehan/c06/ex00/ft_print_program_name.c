#include <unistd.h>

void	ft_putstr(char *a)
{
	while (*a)
		write(1, a++, 1);
	write(1, "\n", 1);
}
int	main(int argc, char *argv[])
{
	ft_putstr(argv[argc - 1]);
}
